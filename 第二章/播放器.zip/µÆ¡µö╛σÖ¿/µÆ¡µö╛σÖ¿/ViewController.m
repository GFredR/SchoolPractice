//
//  ViewController.m
//  播放器
//
//  Created by 郭丰锐 on 2018/3/19.
//  Copyright © 2018年 郭丰锐. All rights reserved.
//

#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>



@interface ViewController ()<UIScrollViewDelegate>
#define W [UIScreen mainScreen].bounds.size.width
#define H [UIScreen mainScreen].bounds.size.height

@property (strong, nonatomic) IBOutlet UILabel *songName;
@property (strong, nonatomic) IBOutlet UILabel *singer;
@property (strong, nonatomic) IBOutlet UIScrollView *album;
@property (strong, nonatomic) IBOutlet UISlider *mp3Slider;
@property (strong, nonatomic) IBOutlet UILabel *totalTime;
@property (strong, nonatomic) IBOutlet UILabel *startTime;
@property (strong, nonatomic) IBOutlet UIPageControl *pictrueControl;


- (IBAction)slider:(UISlider *)sender;
- (IBAction)play:(UIButton *)sender;
- (IBAction)back:(UIButton *)sender;
- (IBAction)forword:(UIButton *)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    //获取数据信息
    //
    NSString* fliePath = [[NSBundle mainBundle]pathForResource:@"song" ofType:@"plist"];
    NSArray* songArr = [NSArray arrayWithContentsOfFile:fliePath];
    
    //
    NSString* fileURL = [[NSBundle mainBundle]pathForResource:[songArr objectAtIndex:0] ofType:@"mp3"];
    NSURL* url = [NSURL fileURLWithPath:fileURL];
    NSLog(@"%@",url);
    NSArray* mp3Arr = [self getMp3Info:url];
    
    _songName.text = [mp3Arr objectAtIndex:1];
    
    
    _singer.text = [mp3Arr objectAtIndex:0];
    
    //
    //
    self.album.bounces = NO;
    
    //不显示水平滑动条
    self.album.showsHorizontalScrollIndicator = NO;
    //
    
    self.album.pagingEnabled = YES;
    //
    self.album.contentSize = CGSizeMake(375*4, 144);
    //
    for (int i = 1; i<= 4; i++) {
        UIImageView* imageView = [[UIImageView alloc]initWithFrame:CGRectMake(375*(i-1), 0, W, 524)];
        NSString* name = [NSString stringWithFormat:@"home_%d.jpg",i];
        imageView.image = [UIImage imageNamed:name];
        [_album addSubview:imageView];
    }
    
}
//获取mp3文件信息，artist、albumName、title、artwork等信息
-(NSArray *)getMp3Info:(NSURL *)url{
    // 初始化媒体文件
    
    NSMutableArray *mp3 = [[NSMutableArray alloc]initWithCapacity:4];
    AVURLAsset *mp3Asset = [AVURLAsset URLAssetWithURL:url options:nil];
    // 读取文件中的数据
    for (NSString *format in [mp3Asset availableMetadataFormats]) {
        for (AVMetadataItem *metadataItem in [mp3Asset metadataForFormat:format]) {
            
            //NSLog(@"%@--%@",metadataItem.commonKey,metadataItem.value);
            //artwork这个key对应的value里面存的就是封面缩略图，其它key可以取出其它摘要信息，例如title - 标题
            if ([metadataItem.commonKey isEqualToString:@"title"]) {
                [mp3 addObject:metadataItem.value];
            }
            if ([metadataItem.commonKey isEqualToString:@"artist"]) {
                [mp3 addObject:metadataItem.value];
            }
            if ([metadataItem.commonKey isEqualToString:@"albumName"]) {
                [mp3 addObject:metadataItem.value];
            }
            
            if ([metadataItem.commonKey isEqualToString:@"artwork"]) {
                if (!metadataItem.value) {
                    // 如果音乐没有图片，就返回默认图片
                    [mp3 addObject:[UIImage imageNamed:@"audio_list.png"]];
                }
                [mp3 addObject:(UIImage *)[UIImage imageWithData:(NSData *)metadataItem.value]];
                break;
            }
            
        }
    }
    return mp3;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    int page = _album.contentOffset.x/W;
    
    _pictrueControl.currentPage = page;
}

- (IBAction)slider:(UISlider *)sender {
}

- (IBAction)play:(UIButton *)sender {
    [sender setImage:[UIImage imageNamed:@"pause"] forState:UIControlStateNormal];
}

- (IBAction)back:(UIButton *)sender {
}

- (IBAction)forword:(UIButton *)sender {
}
@end
